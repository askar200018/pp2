using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace prog
{
    class prog
    {
            /*
	public static void ex()
	{
		string p = @"C:\Users\User\Desktop\Codi\inputs.txt";
		FileInfo file = new FileInfo(p);
		Console.WriteLine(file.name);
	}    */
	public static void Main()
    {
		            
    }
}
}
